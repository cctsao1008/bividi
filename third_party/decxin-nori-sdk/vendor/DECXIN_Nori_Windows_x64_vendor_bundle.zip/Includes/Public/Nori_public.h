

#ifndef __PUBLIC_CLASS_HXX__
#define __PUBLIC_CLASS_HXX__

#include <string>
#include <stdint.h>
#include <windows.h>
#include <strmif.h>
#include <mutex>
#include <thread>
#include <vector>
#include <queue>
#include <condition_variable>

/**
 *  @brief  动态库导入导出定义
 *  @brief  Import and export definition of the dynamic library
 */

#ifndef NORI_CAMCTRL_API

#if (defined (_WIN32) || defined(WIN64))
#if defined(NORI_CAMCTRL_EXPORTS)
#define NORI_CAMCTRL_API __declspec(dllexport)
#define NORI_IMAGECTRL_API __declspec(dllexport)
#else
#define NORI_CAMCTRL_API __declspec(dllimport)
#define NORI_IMAGECTRL_API __declspec(dllimport)
#endif
#else
#ifndef __stdcall
#define __stdcall
#endif

#ifndef NORI_CAMCTRL_API
#define  NORI_CAMCTRL_API
#endif
#endif

#endif

#ifndef IN
#define IN
#endif

#ifndef OUT
#define OUT
#endif


#define POINT_DEL(__pd__)	if(__pd__)		{delete __pd__; __pd__ = NULL;}

#define POINTS_DEL(__pd__)	if(__pd__)		{delete [] __pd__; __pd__ = NULL;}

#define WIN_POINT_DEL(__pd__) if(__pd__)	{__pd__->Release(); __pd__ = NULL;}

#define	STR(Tpx)	#Tpx

#define WIN_CCPOINT_DEL(__pd__)	if(__pd__)	{ __pd__.Release(); }

#define DELETE_ARRARG(_p_)   if((_p_) != NULL){delete [] ((uint8_t*)_p_); (_p_) = NULL;}

#define DELETE_UNIT(_p_)     if((_p_) != NULL){delete    (_p_); (_p_) = NULL;}


/// \~chinese 图像描述       
/// \~english description
typedef struct _VIDEO_INFO_
{

	uint32_t    u_Format;								///< [OUT] \~chinese 媒体类型,具体请看_E_VIDEO_MEDIA_TYPE_枚举
														///< [OUT] \~english Media Reserved，see _E_VIDEO_MEDIA_TYPE_ enumeration for details
	uint32_t    u_Width;								///< [OUT] \~chinese 图像宽度                     \~english Image width
	uint32_t    u_Height;								///< [OUT] \~chinese 图像高度                     \~english Image height
	float		f_Fps;									///< [OUT] \~chinese 图像帧率                     \~english Image frame rate
}VIDEO_INFO;


/// \~chinese 图像数据       
///	\~english Image data
typedef struct _FRAME_BUFFER_OUT_
{
	BYTE*		pBufAddr = nullptr;						///< [OUT] \~chinese 缓存地址                     \~english Buf Address
	uint32_t	u_FrameLen = 0;							///< [OUT] \~chinese 帧长度						  \~english Frame Len
	uint64_t	u_FrameNum = 0;							///< [OUT] \~chinese 帧数						  \~english Frame Number
	FILETIME	Frame_Time{};							///< [OUT] \~chinese 帧时间						  \~english Frame Time
	struct {
		float f_Fps = 0.0f;								///< [OUT] \~chinese 帧率						  \~english Fps
		uint32_t u_Format = 0;							///< [OUT] \~chinese 帧格式						  \~english Frame Format
		uint32_t u_Width = 0;							///< [OUT] \~chinese 帧宽度						  \~english Frame Width
		uint32_t u_Height = 0;							///< [OUT] \~chinese 帧高度						  \~english Frame Height
	} PixFormat;

	uint32_t	capacity = 0;							///< [OUT] \~chinese 传输进度					  \~english capacity
}FRAME_BUFFER_OUT;

/// \~chinese 设备信息       
///	\~english Device information
typedef struct _DEVICE_INFO_
{
	unsigned short idVendor;							///< [OUT] \~chinese 设备厂商ID					 \~english Vendor ID
	unsigned short idProduct;							///< [OUT] \~chinese 设备产品ID                  \~english Product ID
	unsigned short bcdDevice;							///< [OUT] \~chinese 设备版本号                  \~english Device Version (BCD)

	unsigned char iManufacturer[MAX_PATH];				///< [OUT] \~chinese 厂商字符串                  \~english Manufacturer String
	unsigned char iProduct[MAX_PATH];					///< [OUT] \~chinese 产品字符串                  \~english Product String
	unsigned char iSerialNumber[MAX_PATH];				///< [OUT] \~chinese 序列号                      \~english Serial Number

	unsigned long  bcdUSB;								///< [OUT] \~chinese USB版本号                   \~english USB Version (BCD)
	unsigned short portNum;								///< [OUT] \~chinese 端口号                      \~english Port Number
	unsigned short DevNum;								///< [OUT] \~chinese 设备号                      \~english Device Number
	unsigned char hubName[MAX_PATH];					///< [OUT] \~chinese HUB 名称                    \~english HUB Name
	unsigned char PDO[MAX_PATH];						///< [OUT] \~chinese 物理设备对象路径            \~english Physical Device Object Path
	unsigned char deviceID[MAX_PATH];					///< [OUT] \~chinese 设备ID字符串                \~english Device ID String
	unsigned char friendlyName[MAX_PATH];				///< [OUT] \~chinese 设备友好名称                \~english Friendly Name
	unsigned short Reserved;							///< [OUT] \~chinese 保留字段                    \~english Reserved
} DEVICE_INFO;

/// \~chinese 版本信息        
///	\~english Version Information
typedef struct _VERSION_INFO_ 
{
	unsigned char SDKVersion[MAX_PATH];					///< [OUT] \~chinese SDK版本号					\~english SDK version
	/*
	Gen56
	Gen60
	*/
	unsigned char DeviceType[MAX_PATH];					///< [OUT] \~chinese 设备型号					\~english Device type
	unsigned char ISPVersion[MAX_PATH];					///< [OUT] \~chinese ISP版本号					\~english ISP version
	unsigned char FPGAVersion[MAX_PATH];				///< [OUT] \~chinese FPGA版本号					\~english FPGA firmware version
}VERSION_INFO;

/********************************************************************//**
*@brief							CN:回调函数				EN:Callback function
*@param[out] Media_Type			CN:媒体类型				EN:Media Reserved
*@param[out] pdata				CN:帧数据				EN;Frame data
*@param[out] size				CN:帧数据长度			EN:Frame data length
*@param[out] width				CN:帧宽					EN:Frame width
*@param[out] height				CN:帧高					EN:Frame height
*@param[out] arg				CN:用户自定义参数		EN:User-defined parameter
 ************************************************************************/
typedef uint32_t(*PCall_Back_Frame)(uint32_t Media_Type, BYTE* pdata, uint32_t size, uint32_t width, uint32_t height, void* arg);

/********************************************************************//**
*@brief							CN:媒体类型定义			EN:Media Reserved definition
 ************************************************************************/
typedef	enum _E_VIDEO_MEDIA_TYPE_
{
	/********************************************************************//**
	*@brief							CN:MJPEG jpg 数据		EN:MJPEG jpg data
	 ************************************************************************/
	VIDEO_MEDIA_TYPE_MJPG			= 0x47504a4d,

	/********************************************************************//**
	*@brief							CN:YUYV YUV 数据		EN:YUYV YUV data
	 ************************************************************************/
	VIDEO_MEDIA_TYPE_YUY2			= 0x32595559,

/********************************************************************//**
*@brief							CN:MJPEG BGR24 数据		EN:MJPEG BGR24 data
通过 DirectShow 将 mjpeg 数据解码成 BGR24
BGR24数据按从下到上排列（第一行是图像底部)
 ************************************************************************/
	VIDEO_MEDIA_TYPE_MJPG_TO_BGR24	= VIDEO_MEDIA_TYPE_MJPG + 0x01,

/********************************************************************//**
*@brief							CN:YUYV 解码后 数据（BGR24）	EN:YUYV decoded data (BGR24)
通过 DirectShow 将 YUY2 数据解码成 BGR24
BGR24数据按从下到上排列（第一行是图像底部)
 ************************************************************************/
	VIDEO_MEDIA_TYPE_YUY2_TO_BGR24 = VIDEO_MEDIA_TYPE_YUY2 + 0x01,
}E_VIDEO_MEDIA_TYPE;

/// \~chinese Sensor位深
///	\~english Sensor Bit Depth
typedef enum _E_SENSOR_DEPTH_
{
	BAYER_8bit = 0,
	BAYER_10bit,
	BAYER_12bit,
	BAYER_14bit,
	BAYER_16bit,
	BAYER_24bit,
}E_SENSOR_DEPTH;


/// \~chinese RAW 模式下 图像的排列方式,其中每个字母代表一个颜色通道（红、绿、蓝）
/// \~english Image arrangement in RAW mode, where each letter represents a color channel (Red, Green, Blue)
typedef enum _E_SENSOR_COLOR_CODING_
{
	BAYER_GRBG = 0,
	BAYER_RGGB,
	BAYER_BGGR,
	BAYER_GBRG,
}E_SENSOR_COLOR_CODING;

/// \~chinese GPIO ID
/// \~english GPIO ID
typedef enum _E_GPIO_ID_
{
	//Gen56
	GPIO_0		= 0,
	GPIO_1		= 1,

	//Gen60
	GPIO_PIN7	= 1,
	GPIO_PIN6	= 2,
	GPIO_PIN34	= 4,
}E_GPIO_ID;

/// \~chinese	视频类型
/// \~english	Video Type
typedef enum _E_VIDEO_TYPE_
{
	RBG_TYPE = 0,
	MONO_TYPE,
	RAW_TYPE,
}E_VIDEO_TYPE;

/// \~chinese	触发模式
/// \~english	Trigger Mode
typedef enum _E_TRIGGER_MODE_
{
	NON_TRIIGER_MODE = 0,
	SOFTWARE_TRIIGER_MODE,
	HARDWARE_TRIGGER_MODE,
	COMMAND_TRIGGER_MODE,
	KEY_TRIGGER_MODE,
}E_TRIGGER_MODE;

/// \~chinese	图像左右互换
/// \~english	Sensor Mirror Flip Status
typedef enum _E_SENSOR_MIRROR_FLIP_
{
	Normal = 0,
	MIRROR_EN,
	FLIP_EN,
	MIRROR_FLIP_EN,
}E_SENSOR_MIRROR_FLIP;

/// \~chinese	图像偏移
/// \~english	Image Offset
typedef struct _XY_OFFSET_
{
	uint32_t width_offset;
	uint32_t height_offset;
}XY_OFFSET;

/// \~chinese	RGB增益
/// \~english	RGB Gain
typedef struct _WB_RGB_GAIN_
{
	uint32_t gain_r;
	uint32_t gain_g;
	uint32_t gain_b;
}WB_RGB_GAIN;

 /// \~chinese	RAW 描述信息
 /// \~english	RAW description information
typedef struct _SENSOR_RAW_INFO_
{
	E_SENSOR_DEPTH raw_depth;

	E_SENSOR_COLOR_CODING raw_color_coding;
}SENSOR_RAW_INFO;

/// \~chinese	GPIO 模式
/// \~english	GPIO Mode
typedef enum _E_GPIO_MODE_
{
	OUTPUT_MODE = 4,
	INPUT_MODE  = 0,
}E_GPIO_MODE;

/// \~chinese	GPIO 电压水平
/// \~english	GPIO LEVEL
typedef enum _E_GPIO_LEVEL_
{
	LOW = 0,
	HIGH = 8,
}E_GPIO_LEVEL;

/// \~chinese	IO 控制
/// \~english	IO Control
typedef struct _IO_CONTORL_
{
	E_GPIO_MODE gpio_mode; /**< \~chinese 输出模式：4：输入模式：0
							*   \~english Output mode; 4: Input mode 0
							*/

	E_GPIO_LEVEL gpio_level; /**< \~chinese 低电平：0：高电平：8
							  *   \~english Low level: 0; High level: 8
							  */

} IO_CONTORL;

/// \~chinese	PWM频率和占空比
/// \~english	PWM frequency&ratio
typedef struct _FREQUENCY_RATIO_
{
	uint32_t frequency;
	uint32_t ratio;
}FREQUENCY_RATIO;

#endif //__PUBLIC_CLASS_HXX__

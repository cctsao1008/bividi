#pragma once

#include "../Public/Nori_public.h"
#include "../Public/Nori_Error_Define.h"

#ifdef __cplusplus
extern "C" {
#endif 


	/**
	* @defgroup Firmware Firmware
	*
	* @~chinese
	* @brief 固件控制接口
	* @details
	*  - 获取固件信息：
	*    VID、PID、BCD、Manufacturer、SerialNumber、Product、AudioProduct、ESN
	*  - 设置固件信息：
	*    VID、PID、Manufacturer、SerialNumber、Product、AudioProduct、ESN
	* @note 各字符串最大有效长度 (字节)：
	*
	* | 名称           | Gen56 | Gen60 |
	* |----------------|-------|-------|
	* | bcdDevice       | 4     | 8     |
	* | iManufacturer  | 32    | 47    |
	* | iProduct       | 32    | 47    |
	* | iSerialNumber  | 32    | 47    |
	* | AudioProduct   | 32    | 47    |
	* | EXID           | 16    | 64    |
	*
	* @~english
	* @brief Firmware control interfaces
	* @details
	*  - Get firmware information:
	*    VID, PID, BCD, Manufacturer, SerialNumber, Product, AudioProduct, ESN
	*  - Set firmware information:
	*    VID, PID, Manufacturer, SerialNumber, Product, AudioProduct, ESN
	* @note Maximum valid length (bytes) for each string:
	*
	* | Name           | Gen56 | Gen60 |
	* |----------------|-------|-------|
	* | bcdDevice       | 4     | 8     |
	* | iManufacturer  | 32    | 47    |
	* | iProduct       | 32    | 47    |
	* | iSerialNumber  | 32    | 47    |
	* | AudioProduct   | 32    | 47    |
	* | EXID           | 16    | 64    |
	*
	* @{
	*/



	/********************************************************************//**
	* @ingroup Firmware
	* @~chinese
	* @brief  固件配置初始化
	* @param  pFwData [IN] 固件数据地址，不可为 NULL
	* @param  uFwSize [IN] 固件数据长度（字节），必须大于 0
	* @param  pFwType [OUT] 固件类型
	*		  - 110: Gen56
	*		  - 115: Gen60
	* @return 固件配置句柄
	*         - 成功：非 NULL
	*         - 失败：NULL
	* @note   使用完成后需调用 Nori_Xvision_FirmwareUnInit 释放
	*
	* @~english
	* @brief  Firmware configuration initialization
	* @param  pFwData [IN] Firmware data address, must not be NULL
	* @param  uFwSize [IN] Firmware data length in bytes, must be greater than 0
	* @param  pFwType [OUT] Firmware type
	*		  - 110: Gen56
	*		  - 115: Gen60
	* @return Firmware configuration handle
	*         - Success: non-NULL
	*         - Failure: NULL
	* @note   Must be released by Nori_Xvision_FirmwareUnInit()
	************************************************************************/
	NORI_CAMCTRL_API void* Nori_Xvision_FirmwareInit(IN uint8_t* pFwData, IN uint32_t uFwSize, OUT uint32_t *pFwType);

	/********************************************************************//**
	* @ingroup Firmware
	* @~chinese
	* @brief  固件配置反初始化，释放函数内部固件数据
	* @param  pFwHandle [IN] 固件配置句柄，由 Nori_Xvision_FirmwareInit 返回
	* @return 执行结果
	*         - NORI_OK：成功
	*         - 其他值：错误码
	*
	* @~english
	* @brief  Firmware configuration de-initialization,Release firmware data inside the function
	* @param  pFwHandle [IN] Firmware configuration handle returned by Init
	* @return Result code
	*         - NORI_OK on success
	*         - Error code on failure
	************************************************************************/
	NORI_CAMCTRL_API uint32_t Nori_Xvision_FirmwareUnInit(IN void* pFwHandle);

	/********************************************************************//**
	* @ingroup Firmware
	* @~chinese
	* @brief  获取设备 Vendor ID
	* @param  pFwHandle [IN]  固件配置句柄
	* @param  pValue    [OUT] 返回 Vendor ID
	* @return NORI_OK 或错误码
	*
	* @~english
	* @brief  Get device Vendor ID
	* @param  pFwHandle [IN]  Firmware configuration handle
	* @param  pValue    [OUT] Vendor ID value
	* @return NORI_OK or error code
	************************************************************************/
	NORI_CAMCTRL_API uint32_t Nori_Xvision_FirmwareGetVID(IN void* pFwHandle, OUT uint16_t* pValue);

	/********************************************************************//**
	* @ingroup Firmware
	* @~chinese
	* @brief  设置设备 Vendor ID
	* @param  pFwHandle [IN] 固件配置句柄
	* @param  uValue    [IN] Vendor ID 值
	* @return NORI_OK 或错误码
	*
	* @~english
	* @brief  Set device Vendor ID
	* @param  pFwHandle [IN] Firmware configuration handle
	* @param  uValue    [IN] Vendor ID value
	* @return NORI_OK or error code
	************************************************************************/
	NORI_CAMCTRL_API uint32_t Nori_Xvision_FirmwareSetVID(IN void* pFwHandle, IN uint16_t uValue);

	/********************************************************************//**
	* @ingroup Firmware
	* @~chinese
	* @brief  获取设备 Product ID
	* @param  pFwHandle [IN]  固件配置句柄
	* @param  pValue    [OUT] 返回 Product ID
	* @return NORI_OK 或错误码
	*
	* @~english
	* @brief  Get device Product ID
	* @param  pFwHandle [IN]  Firmware configuration handle
	* @param  pValue    [OUT] Product ID value
	* @return NORI_OK or error code
	************************************************************************/
	NORI_CAMCTRL_API uint32_t Nori_Xvision_FirmwareGetPID(IN void* pFwHandle, OUT uint16_t* pValue);

	/********************************************************************//**
	* @ingroup Firmware
	* @~chinese
	* @brief  设置设备 Product ID
	* @param  pFwHandle [IN] 固件配置句柄
	* @param  uValue    [IN] Product ID 值
	* @return NORI_OK 或错误码
	*
	* @~english
	* @brief  Set device Product ID
	* @param  pFwHandle [IN] Firmware configuration handle
	* @param  uValue    [IN] Product ID value
	* @return NORI_OK or error code
	************************************************************************/
	NORI_CAMCTRL_API uint32_t Nori_Xvision_FirmwareSetPID(IN void* pFwHandle, IN uint16_t uValue);

	/********************************************************************//**
	* @ingroup Firmware
	* @~chinese
	* @brief  获取设备 BCD 版本号字符串
	* @param  pFwHandle [IN]  固件配置句柄
	* @param  pOut      [OUT] 输出字符串缓冲区，以 '\0' 结尾
	* @return NORI_OK 或错误码
	*
	* @~english
	* @brief  Get device BCD version string
	* @param  pFwHandle [IN]  Firmware configuration handle
	* @param  pOut      [OUT] Output buffer, null-terminated string
	* @return NORI_OK or error code
	************************************************************************/
	NORI_CAMCTRL_API uint32_t Nori_Xvision_FirmwareGetBCD(IN void* pFwHandle, OUT unsigned char* pOut);

	/********************************************************************//**
	* @ingroup Firmware
	* @~chinese
	* @brief  获取厂商字符串
	* @param  pFwHandle [IN]  固件配置句柄
	* @param  pOut      [OUT] 输出字符串缓冲区，以 '\0' 结尾
	* @return NORI_OK 或错误码
	*
	* @~english
	* @brief  Get manufacturer string
	* @param  pFwHandle [IN]  Firmware configuration handle
	* @param  pOut      [OUT] Output buffer, null-terminated string
	* @return NORI_OK or error code
	************************************************************************/
	NORI_CAMCTRL_API uint32_t Nori_Xvision_FirmwareGetManufacturer(IN void* pFwHandle, OUT unsigned char* pOut);

	/********************************************************************//**
	* @ingroup Firmware
	* @~chinese
	* @brief  设置厂商字符串
	* @param  pFwHandle [IN] 固件配置句柄
	* @param  pIn       [IN] 输入字符串，以 '\0' 结尾
	* @return NORI_OK 或错误码
	*
	* @~english
	* @brief  Set manufacturer string
	* @param  pFwHandle [IN] Firmware configuration handle
	* @param  pIn       [IN] Input null-terminated string
	* @return NORI_OK or error code
	************************************************************************/
	NORI_CAMCTRL_API uint32_t Nori_Xvision_FirmwareSetManufacturer(IN void* pFwHandle, IN unsigned char* pIn);

	/********************************************************************//**
	* @ingroup Firmware
	* @~chinese
	* @brief  获取设备序列号字符串
	* @param  pFwHandle [IN]  固件配置句柄
	* @param  pOut      [OUT] 输出字符串缓冲区，以 '\0' 结尾
	* @return NORI_OK 或错误码
	*
	* @~english
	* @brief  Get device serial number string
	* @param  pFwHandle [IN]  Firmware configuration handle
	* @param  pOut      [OUT] Output buffer, null-terminated string
	* @return NORI_OK or error code
	************************************************************************/
	NORI_CAMCTRL_API uint32_t Nori_Xvision_FirmwareGetSerialNumber(IN void* pFwHandle, OUT unsigned char* pOut);

	/********************************************************************//**
	* @ingroup Firmware
	* @~chinese
	* @brief  设置设备序列号字符串
	* @param  pFwHandle [IN] 固件配置句柄
	* @param  pIn       [IN] 输入字符串，以 '\0' 结尾
	* @return NORI_OK 或错误码
	*
	* @~english
	* @brief  Set device serial number string
	* @param  pFwHandle [IN] Firmware configuration handle
	* @param  pIn       [IN] Input null-terminated string
	* @return NORI_OK or error code
	************************************************************************/
	NORI_CAMCTRL_API uint32_t Nori_Xvision_FirmwareSetSerialNumber(IN void* pFwHandle, IN unsigned char* pIn);

	/********************************************************************//**
	* @ingroup Firmware
	* @~chinese
	* @brief  获取产品字符串
	* @param  pFwHandle [IN]  固件配置句柄
	* @param  pOut      [OUT] 输出字符串缓冲区，以 '\0' 结尾
	* @return NORI_OK 或错误码
	*
	* @~english
	* @brief  Get product string
	* @param  pFwHandle [IN]  Firmware configuration handle
	* @param  pOut      [OUT] Output buffer, null-terminated string
	* @return NORI_OK or error code
	************************************************************************/
	NORI_CAMCTRL_API uint32_t Nori_Xvision_FirmwareGetProduct(IN void* pFwHandle, OUT unsigned char* pOut);

	/********************************************************************//**
	* @ingroup Firmware
	* @~chinese
	* @brief  设置产品字符串
	* @param  pFwHandle [IN] 固件配置句柄
	* @param  pIn       [IN] 输入字符串，以 '\0' 结尾
	* @return NORI_OK 或错误码
	*
	* @~english
	* @brief  Set product string
	* @param  pFwHandle [IN] Firmware configuration handle
	* @param  pIn       [IN] Input null-terminated string
	* @return NORI_OK or error code
	************************************************************************/
	NORI_CAMCTRL_API uint32_t Nori_Xvision_FirmwareSetProduct(IN void* pFwHandle, IN unsigned char* pIn);

	/********************************************************************//**
	* @ingroup Firmware
	* @~chinese
	* @brief  获取音频产品字符串
	* @param  pFwHandle [IN]  固件配置句柄
	* @param  pOut      [OUT] 输出字符串缓冲区，以 '\0' 结尾
	* @return NORI_OK 或错误码
	*
	* @~english
	* @brief  Get audio product string
	* @param  pFwHandle [IN]  Firmware configuration handle
	* @param  pOut      [OUT] Output buffer, null-terminated string
	* @return NORI_OK or error code
	************************************************************************/
	NORI_CAMCTRL_API uint32_t Nori_Xvision_FirmwareGetAudioProduct(IN void* pFwHandle, OUT unsigned char* pOut);

	/********************************************************************//**
	* @ingroup Firmware
	* @~chinese
	* @brief  设置音频产品字符串
	* @param  pFwHandle [IN] 固件配置句柄
	* @param  pIn       [IN] 输入字符串，以 '\0' 结尾
	* @return NORI_OK 或错误码
	*
	* @~english
	* @brief  Set audio product string
	* @param  pFwHandle [IN] Firmware configuration handle
	* @param  pIn       [IN] Input null-terminated string
	* @return NORI_OK or error code
	************************************************************************/
	NORI_CAMCTRL_API uint32_t Nori_Xvision_FirmwareSetAudioProduct(IN void* pFwHandle, IN unsigned char* pIn);

	/********************************************************************//**
	* @ingroup Firmware
	* @~chinese
	* @brief  获取设备 ESN / EXID 字符串
	* @param  pFwHandle [IN]  固件配置句柄
	* @param  pOut      [OUT] 输出字符串缓冲区，以 '\0' 结尾
	* @return NORI_OK 或错误码
	*
	* @~english
	* @brief  Get ESN / EXID string
	* @param  pFwHandle [IN]  Firmware configuration handle
	* @param  pOut      [OUT] Output buffer, null-terminated string
	* @return NORI_OK or error code
	************************************************************************/
	NORI_CAMCTRL_API uint32_t Nori_Xvision_FirmwareGetESN(IN void* pFwHandle, OUT unsigned char* pOut);

	/********************************************************************//**
	* @ingroup Firmware
	* @~chinese
	* @brief  设置设备 ESN / EXID 字符串
	* @param  pFwHandle [IN] 固件配置句柄
	* @param  pIn       [IN] 输入字符串，以 '\0' 结尾
	* @return NORI_OK 或错误码
	*
	* @~english
	* @brief  Set ESN / EXID string
	* @param  pFwHandle [IN] Firmware configuration handle
	* @param  pIn       [IN] Input null-terminated string
	* @return NORI_OK or error code
	************************************************************************/
	NORI_CAMCTRL_API uint32_t Nori_Xvision_FirmwareSetESN(IN void* pFwHandle, IN unsigned char* pIn);

	/********************************************************************//**
	* @ingroup Firmware
	* @~chinese
	* @brief  获取固件数据指针
	* @param  pFwHandle   [IN]  固件配置句柄
	* @param  uReserve    [IN]  0x00
	* @param  pOutFwData  [OUT] 返回固件数据地址（内部指针，不可释放）
	* @return NORI_OK 或错误码
	*
	* @~english
	* @brief  Get firmware data pointer
	* @param  pFwHandle   [IN]  Firmware configuration handle
	* @param  uReserve    [IN]  0x00
	* @param  pOutFwData  [OUT] Return firmware data pointer (internal, do not free)
	* @return NORI_OK or error code
	************************************************************************/
	NORI_CAMCTRL_API uint32_t Nori_Xvision_FirmwareGetData(IN void* pFwHandle, IN uint32_t uReserve, OUT uint8_t** pOutFwData);

	/********************************************************************//**
	* @ingroup Firmware
	* @~chinese
	* @brief  获取固件数据长度
	* @param  pFwHandle  [IN]  固件配置句柄
	* @param  uReserve   [IN]  0x00
	* @param  pOutFwSize [OUT] 返回固件数据长度（字节）
	* @return NORI_OK 或错误码
	*
	* @~english
	* @brief  Get firmware data length
	* @param  pFwHandle  [IN]  Firmware configuration handle
	* @param  uReserve   [IN]  0x00
	* @param  pOutFwSize [OUT] Return firmware data length in bytes
	* @return NORI_OK or error code
	************************************************************************/
	NORI_CAMCTRL_API uint32_t Nori_Xvision_FirmwareGetLen(IN void* pFwHandle, IN uint32_t uReserve, OUT uint32_t* pOutFwSize);

	/** @} endgroup Firmware */

#ifdef __cplusplus
}
#endif

/**
 * @mainpage Nori_Xvision_Development_Kit_Ver10.00.10_Windows
 *
 * @~chinese
 * @section 概述
 * 本头文件定义了设备SDK的核心接口，包括以下7部分：
 * - 1. SDK 初始化与反初始化
 * - 2. 设备信息获取
 * - 3. 固件更新、用户数据读写
 * - 4. 图像采集与参数控制
 * - 5. Sensor 控制
 * - 6. 其他设备功能
 * - 7. 图像解码
 * - 8. 固件控制
 *
 * @section 支持平台
 * windows 10、windows 11
 *
 * 
 * @~english
 * @section Overview
 * This header defines the core interfaces of the Camera SDK, including:
 * - 1. SDK initialization and deinitialization
 * - 2. Device information access
 * - 3. Firmware update and user data access
 * - 4. Image acquisition and parameter control
 * - 5. Sensor control
 * - 6. Other camera functions
 * - 7. Image Decoding
 * - 8. Firmware Control
 *	
 * @section Supported Platforms
 * windows 10、windows 11
 */

#pragma once
#include "../Public/Nori_public.h"
#include "../Public/Nori_Error_Define.h"


#ifdef __cplusplus
extern "C" {
#endif 

/**
 * @defgroup Device Device
 * @brief
 * @~chinese 设备控制
 * @~english Device Control
 *@{
 */

/************************** SDK Init & Uninit **************************/

/**
* @defgroup SDK_Init_Uninit SDK_Init_Uninit
* @ingroup Device
* @brief
* @~chinese 初始化、反初始化、设备枚举
* @~english Init & Uninit, Device Enumeration
* @{
*/
/********************************************************************//**
*	@ingroup SDK_Init_Uninit
*	@~chinese
*	@brief		初始化SDK、枚举设备	
*	@param		uLayerType					[IN]			枚举传输层类型（参见 Nori_Error_Define.h）	
*	@param		pDeviceNum					[IN][OUT]		返回发现的设备数量	
*	@remarks	此接口必须在其他接口之前进行调用
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Initializes SDK resources、Enumeration Device
*	@param		uLayerType					[IN]			Transport layer type (see Nori_Error_Define.h)
*	@param		pDeviceNum					[IN][OUT]		Returns the number of detected devices	
*	@remarks	This interface must be called before other interfaces
*	@return		Success, return NORI_OK; Error, return error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_Init(IN uint32_t uLayerType, IN OUT uint32_t* pDeviceNum);

/********************************************************************//**
*	@ingroup SDK_Init_Uninit
*	@~chinese
*	@brief		反初始化SDK，释放资源	
*	@remarks	此接口必须在最后释放进行调用
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		SDK UnInitialization
*	@remarks	This interface must be called before other interfaces
*	@return		Success, return NORI_OK; Error, return error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_UnInit();

/** @} endgroup SDK_Init_Uninit */


/************************** Device Info **************************/

/**
 * @defgroup Device_Info Device_Info
 * @ingroup Device
 * @brief
 * @~chinese 获取设备相关信息
 * @~chinese - 设备版本信息
 * @~chinese - 设备描述信息
 * @~chinese - 视频流描述信息
 * @~english Get device information
 * @~english - Device version information
 * @~english - Device description information
 * @~english - Video stream description information
 * @{
 */

/********************************************************************//**
*	@ingroup Device_Info
*	@~chinese
*	@brief		获取版本信息
*	@param		uDeviceID					[IN]			设备索引
*	@param		pVersion					[IN][OUT]		输出版本信息结构体（见 VERSION_INFO）
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Get Version info
*	@param		uDeviceID					[IN]			Device index
*	@param		pVersion					[IN][OUT]		Output version information (see VERSION_INFO)
*	@return		Success, return NORI_OK; Error, return error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_GetVersion(IN uint32_t uDeviceID, IN OUT VERSION_INFO* pVersion);



/********************************************************************//**
*	@ingroup Get_Device_Info
*	@~chinese
*	@brief		获取设备描述信息			
*	@param		uDeviceID					[IN]			设备索引								
*	@param		pDeviceInfo					[IN][OUT]		输出设备描述（见 DEVICE_INFO）							
*	@return		成功，返回NORI_OK；错误，返回错误码			

*	@~english
*	@brief		Get Version info
*	@param		uDeviceID					[IN]			Device index
*	@param		pDeviceInfo					[IN][OUT]		Output device description (see DEVICE_INFO)
*	@return		Success, return NORI_OK; Error, return error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_GetDeviceInfo(IN uint32_t uDeviceID, IN OUT DEVICE_INFO* pDeviceInfo);

/********************************************************************//**
*	@ingroup Get_Device_Info
*	@~chinese
*	@brief		获取支持的视频格式/分辨率/帧率个数
*	@param		uDeviceID					[IN]			设备索引
*	@param		pNum						[IN][OUT]		输出视频格式信息数量
*	@remarks	此接口在初始化后优先调用，以便后续操作
*	@return		设备视频格式&分辨率&默认帧率 数量

*	@~english
*	@brief		Get the number of video formats, resolutions, and frame rates supported by the camera
*	@param		uDeviceID					[IN]			Device index
*	@param		pNum						[IN][OUT]		CThe number of video formats, resolutions, and frame rates supported by the camera
*	@remarks	This interface should be called immediately after initialization to ensure subsequent operations work correctly
*	@return		The number of video formats, resolutions, and frame rates supported by the camera
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_GetDeviceVideoInfoSize(IN uint32_t uDeviceID, IN OUT uint32_t* pNum);

/********************************************************************//**
*	@ingroup Get_Device_Info
*	@~chinese
*	@brief		获取指定索引的视频格式/分辨率/帧率信息
*	@param		uDeviceID					[IN]			设备索引
*	@param		uVideoInfoIndex				[IN]			视频格式&分辨率&默认帧率 索引
*	@param		pVideoInfo					[IN][OUT] 		视频格式&分辨率&默认帧率 值	
*	@remarks	仅能获取最大帧率
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Get the video format, resolution, and frame rate values for the indexed camera
*	@param		uDeviceID					[IN]			Device index
*	@param		uVideoInfoIndex				[IN]			Video Format, Resolution, and Frame Rate Index
*	@param		pVideoInfo					[IN][OUT] 		Video Format, Resolution, and Frame Rate Value
*	@remarks	Only the maximum frame rate can be obtained
*	@return		Success, return NORI_OK; Error, return error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_GetDeviceVideoInfo(IN uint32_t uDeviceID, IN uint32_t uVideoInfoIndex, IN OUT VIDEO_INFO *pVideoInfo);

/** @} endgroup Device_Info */

/************************** Video Stream **************************/

/**
 * @defgroup Video_Stream Video_Stream
 * @ingroup Device
 * @brief
 * @~chinese 视频流控制
 * @~chinese - 初始化视频采集
 * @~chinese - 注册视频帧回调函数
 * @~chinese - 反初始化视频采集
 * @~chinese - 查询视频流状态
 * @~chinese - 启动视频采集
 * @~chinese - 停止视频采集
 * @~chinese - 主动获取帧数据
 * @~chinese - 帧资源回收
 * @~english Video stream
 * @~english - Initialize video capture
 * @~english - Register the video frame callback function
 * @~english - Reverse Initialization Video Capture
 * @~english - Query the video stream status
 * @~english - Start video capture
 * @~english - Stop video capture
 * @~english - Proactively retrieve frame data
 * @~english - Frame Resource Recycling
 * @{
 */

 /********************************************************************//**
 *	@ingroup Video_Stream
 *	@~chinese
 *	@brief		初始化视频采集，配置像素格式/分辨率/帧率
 *	@param		uDeviceID					[IN] 			设备索引
 *	@param		user						[IN] 			视频流格式&分辨率&帧率
 *	@remarks	视频流格式设置详细在VIDEO_INFO中有说明
 *	@remarks 	该接口在开始采集前调用
 *	@return		成功，返回NORI_OK；错误，返回错误码

 *	@~english
 *	@brief		Sets the video stream format, resolution, and frame rate
 *	@param		uDeviceID					[IN]			Device index
 *	@param		user						[IN][OUT] 		Video stream format, resolution, and frame rate
 *	@remarks	Details on video stream format settings are described in VIDEO_INFO
 * 	@remarks 	Call before starting capture.
 *	@return		Success, return NORI_OK; Error, return error code
  ************************************************************************/
NORI_CAMCTRL_API uint32_t	Nori_Xvision_DeviceVideoInit(IN uint32_t uDeviceID, IN VIDEO_INFO User);


/********************************************************************//**
*	@ingroup Video_Stream
*	@~chinese
*	@brief		注册视频帧回调函数
*	@param		uDeviceID					[IN] 			设备索引
*	@param		pexe						[IN] 			回调函数
*	@param		pUser						[IN] 			回调时传递的用户数据指针
*	@remarks	检测到新的帧数据，触发回调函数
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Register video frame callback
*	@param		uDeviceID					[IN]			Device index
*	@param		pexe						[IN] 			Callback function
*	@param		pUser						[IN] 			User-defined parameters
*	@remarks	Triggers the callback function when new frame data is detected
*	@return		Success, return NORI_OK; Error, return error code
************************************************************************/
NORI_CAMCTRL_API uint32_t	Nori_Xvision_VideoCallBack(IN uint32_t uDeviceID, IN PCall_Back_Frame pexe, IN void * pUser);


/********************************************************************//**
*	@ingroup Video_Stream
*	@~chinese
*	@brief		反初始化视频采集，释放相关资源
*	@param		uDeviceID					[IN] 			设备索引
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Frees the video stream node memory
*	@param		uDeviceID					[IN]			Device index
*	@return		Success, return NORI_OK; Error, return error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t	Nori_Xvision_DeviceVideoUnInit(IN uint32_t uDeviceID);


/********************************************************************//**
*	@ingroup Video_Stream
*	@~chinese
*	@brief		开启视频流
*	@param		uDeviceID					[IN] 			设备索引
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Starts the video stream
*	@param		uDeviceID					[IN]			Device index
*	@return		Success, return NORI_OK; Error, return error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t	Nori_Xvision_VideoStart(IN uint32_t uDeviceID);

/********************************************************************//**
*	@ingroup Video_Stream
*	@~chinese
*	@brief		关闭视频流
*	@param		uDeviceID					[IN] 			设备索引
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Stops the video stream
*	@param		uDeviceID					[IN]			Device index
*	@return		Success, return NORI_OK; Error, return error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t	Nori_Xvision_VideoStop(IN uint32_t uDeviceID);

/********************************************************************//**
*	@ingroup Video_Stream
*	@~chinese
*	@brief		主动获取一帧数据
*	@param		uDeviceID					[IN] 			设备索引
*	@param		pFrame						[IN][OUT] 		帧数据
*	@param		uMsec						[IN] 			阻塞超时（毫秒）
*	@remarks	函数调用一次获取一帧数据
				帧资源使用结束后必须通过Nori_XVISION_FreeFrameBuff函数进行帧资源回收
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Actively Get a single frame of data
*	@param		uDeviceID					[IN]			Device index
*	@param		pFrame						[IN][OUT] 		Frame data
*	@param		uMsec						[IN] 			Timeout in milliseconds
*	@remarks	The function retrieves one frame of data per call
				After using the frame resource, it must be released by calling the Nori_XVISION_FreeFrameBuff function
*	@return		Success, return NORI_OK; Error, return error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_GetFrameBuff(IN uint32_t uDeviceID, IN OUT FRAME_BUFFER_OUT **pFrame, IN uint32_t uMsec);

/********************************************************************//**
*	@ingroup Video_Stream
*	@~chinese
*	@brief		帧回收
*	@param		uDeviceID					[IN] 			设备索引
*	@param		pFrame						[IN]	 		要释放的帧指针
*	@remarks	函数调用一次回收一帧数据
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Frame data reclamation
*	@param		uDeviceID					[IN]			Device index
*	@param		pFrame						[IN] 			Frame pointer to free
*	@remarks	The function recycle one frame of data per call
*	@return		Success, return NORI_OK; Error, return error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_FreeFrameBuff(IN uint32_t uDeviceID, IN FRAME_BUFFER_OUT* pFrame);

/** @} endgroup Video_Stream */


/**
 * @defgroup Trigger_Control Trigger_Control
 * @ingroup Device
 * @brief
 * @~chinese 触发控制（软件/硬件/指令）
 * @~chinese - 触发模式配置
 * @~chinese  - 软件触发：先设置软件触发模式，后设置软件触发频率
 * @~chinese  - 硬件触发：先设置硬件触发模式，后外部提供脉冲信号
 * @~chinese  - 指令触发：先设置指令触发模式，后续每调用一次指令触发指令函数，输出一帧图像数据
 * @~chinese - 软件触发频率配置
 * @~chinese - 指令触发指令
 * @~english Trigger control (software/hardware/command/button)
 * @~english - Trigger Mode Configuration
 * @~english  - Software triggering: First set the software triggering mode, then set the software triggering frequency
 * @~english  - Hardware triggering: Set the hardware triggering mode first, and then provide pulse signals externally
 * @~english  - Instruction triggering: First set the instruction triggering mode, and then every time the instruction triggering function is called, output one frame of image data
 * @~english - Software trigger frequency configuration
 * @~english - Instruction triggers instruction
 * @{
 */

 /********************************************************************//**
 *	@ingroup Trigger_Control
 *	@~chinese
 *	@brief		获取触发模式
 *	@param		uDeviceID					[IN] 				设备索引
 *	@param		pValue						[IN][OUT]			返回当前触发模式（参见 E_TRIGGER_MODE）
 *	@return		成功，返回NORI_OK；错误，返回错误码

 *	@~english
 *	@brief		Get Trigger Mode
 *	@param		uDeviceID					[IN] 				Device index
 *	@param		pValue						[IN][OUT]			Returns current trigger mode (see E_TRIGGER_MODE)
 *	@return		Success returns NORI_OK; Error returns an error code
  ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_GetTriggerMode(IN uint32_t uDeviceID, IN OUT E_TRIGGER_MODE *pValue);

/********************************************************************//**
*	@ingroup Trigger_Control
*	@~chinese
*	@brief		设置触发模式
*	@param		uDeviceID					[IN] 				设备索引
*	@param		pValue						[IN]				要设置的触发模式（参见 E_TRIGGER_MODE）
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Set Trigger Mode
*	@param		uDeviceID					[IN] 				Device index
*	@param		pValue						[IN]				Trigger mode to set (see E_TRIGGER_MODE)
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_SetTriggerMode(IN uint32_t uDeviceID, IN E_TRIGGER_MODE uValue);

/********************************************************************//**
*	@ingroup Trigger_Control
*	@~chinese
*	@brief		获取软件触发频率（单位：Hz）
*	@param		uDeviceID					[IN] 				设备索引
*	@param		pValue						[IN][OUT] 			触发频率值
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		 Get software trigger frequency (unit: Hz or implementation-specific)
*	@param		uDeviceID					[IN] 				Device index
*	@param		pValue						[IN][OUT] 			Trigger frequency value
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_GetTriggerFrequency(IN uint32_t uDeviceID, IN OUT  uint32_t *pValue);


/********************************************************************//**
*	@ingroup Trigger_Control
*	@~chinese
*	@brief		设置软件触发频率（单位：Hz）
*	@param		uDeviceID					[IN] 				设备索引
*	@param		pValue						[IN] 				触发频率值
*	@remarks	进行触发频率设置前，需先将触发模式设置为软件触发模式，可通过 Nori_Xvision_SetTriggerMode 接口进行设置
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Set software trigger frequency (unit: Hz or implementation-specific)
*	@param		uDeviceID					[IN] 				Device index
*	@param		pValue						[IN] 				Trigger frequency value
*	@remarks	Before setting the Trigger frequency, make sure to set the Trigger mode to manual mode using the Nori_Xvision_SetTriggerMode
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_SetTriggerFrequency(IN uint32_t uDeviceID, IN uint32_t uValue);


/********************************************************************//**
*	@ingroup Trigger_Control
*	@~chinese
*	@brief		发送一次指令触发（一次调用触发一帧）
*	@param		uDeviceID					[IN] 				设备索引
*	@remarks	需先通过 Nori_Xvision_SetTriggerMode 设置触发模式为 3 指令触发
*	@remarks	调用一次此函数，触发输出一帧
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Send a command trigger (one call triggers one frame)
*	@param		uDeviceID					[IN] 				Device index
*	@remarks	Ensure that the trigger mode is set to 3 (command trigger) using Nori_Xvision_SetTriggerMode before calling this function
*	@remarks	Calling this function once will trigger the output of one frame
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_SetTriggerCommand(IN uint32_t uDeviceID);

/** @} endgroup Trigger_Control */


/************************** UVC Processing Unit Control **************************/

/**
 * @defgroup UVC_PU UVC_PU
 * @ingroup Device
 * @brief
 * @~chinese UVC Processing Unit 控制（亮度/对比度/增益/曝光等）
 * @~chinese - 标准UVC Processing Unit 控制
 * @~chinese - tagVideoProcAmpProperty
 * @~chinese  - VideoProcAmp_Brightness					        亮度
 * @~chinese  - VideoProcAmp_Contrast					        对比度
 * @~chinese  - VideoProcAmp_Hue						        色调
 * @~chinese  - VideoProcAmp_Saturation					        饱和度
 * @~chinese  - VideoProcAmp_Sharpness					        清晰度
 * @~chinese  - VideoProcAmp_Gamma						        伽玛
 * @~chinese  - VideoProcAmp_WhiteBalance						白平衡 开关(1 自动模式 ,2 手动模式)
 * @~chinese  - VideoProcAmp_BacklightCompensation				逆光对比
 * @~chinese  - VideoProcAmp_Gain						        增益
 * @~chinese  - 13												电力线频率(1 50HZ ,2 60HZ)
 * @~chinese - tagCameraControlProperty
 * @~chinese  - CameraControl_Pan								全景
 * @~chinese  - CameraControl_Tilt								倾斜
 * @~chinese  - CameraControl_Roll						        滚动
 * @~chinese  - CameraControl_Zoom								缩放
 * @~chinese  - CameraControl_Exposure					        曝光
 * @~chinese  - CameraControl_Iris						        光圈
 * @~chinese  - CameraControl_Focus								焦点 开关(1 自动模式 ,2 手动模式,)
 * @~chinese  - 19												低亮度补偿(0 取消低亮度补偿 1勾选低亮度补偿)
 * @~english UVC Processing Unit Controls (brightness/contrast/gain/exposure/etc.)
 * @~english - Standard UVC Processing Unit Controls
 * @~english - tagVideoProcAmpProperty
 * @~english  - VideoProcAmp_Brightness							Brightness
 * @~english  - VideoProcAmp_Contrast							Contrast
 * @~english  - VideoProcAmp_Hue								Hue
 * @~english  - VideoProcAmp_Saturation							Saturation
 * @~english  - VideoProcAmp_Sharpness							Sharpness
 * @~english  - VideoProcAmp_Gamma								Gamma
 * @~english  - VideoProcAmp_WhiteBalance						Auto white balance (1 = auto ,2 = manual)
 * @~english  - VideoProcAmp_BacklightCompensation				Manual white balance value
 * @~english  - V4L2_CID_BACKLIGHT_COMPENSATION					Backlight compensation
 * @~english  - VideoProcAmp_Gain								Gain
 * @~english  - 13												Power line frequency(1 50HZ ,2 60HZ)
 * @~english - tagCameraControlProperty
 * @~english  - CameraControl_Pan								Pan
 * @~english  - CameraControl_Tilt								Tilt
 * @~english  - CameraControl_Roll								Roll
 * @~english  - CameraControl_Zoom								Zoom
 * @~english  - CameraControl_Exposure							Exposure
 * @~english  - CameraControl_Iris								Iris
 * @~english  - CameraControl_Focus								Focus
 * @~english  - 19												Low-light compensation (0 = fixed FPS，1 = auto FPS drop in low light)
 * @{
 */

 /********************************************************************//**
*	@ingroup UVC_PU
*	@~chinese
*	@brief		获取Processing unit control
*	@param		uDeviceID					[IN] 				设备索引
*	@param		VideoProcAmp				[IN] 				Processing unit 属性,参数定义参见strmif.h定义
*	@param		val							[IN][OUT] 			当前值
*	@param		flags						[IN][OUT] 			自动/手动
*	@param		step						[IN][OUT] 			步长
*	@param		min							[IN][OUT] 			最小值
*	@param		max							[IN][OUT] 			最大值
*	@param		def							[IN][OUT] 			默认值
*	@param		pCapsFlags					[IN][OUT] 			获取当前设备PU属性支持的控制模式,如:1，自动控制；2：手动控制；3：自动、手动控制
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Processing unit control retrieval
*	@param		uDeviceID					[IN] 				Device index
*	@param		VideoProcAmp				[IN] 				Processing unit property For more details, refer to strmif.h.
*	@param		val							[IN][OUT] 			Current value
*	@param		flags						[IN][OUT] 			Automatic/manual
*	@param		step						[IN][OUT] 			Step size
*	@param		min							[IN][OUT] 			Minimum value
*	@param		max							[IN][OUT] 			Maximum value
*	@param		def							[IN][OUT] 			Default value
*	@param		pCapsFlags					[IN][OUT] 			Get the control mode supported by the current device's PU (Processing Unit) properties. For example: 1: Automatic control; 2: Manual control; 3: Both automatic and manual control
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_GetProcessingUnitControl(IN uint32_t uDeviceID, IN enum tagVideoProcAmpProperty VideoProcAmp, IN OUT long *pval, IN OUT long *flags, IN OUT long *step, IN OUT long*min, IN OUT long* max, IN OUT long *def, IN OUT long *pCapsFlags);

/********************************************************************//**
*	@ingroup UVC_PU
*	@~chinese
*	@brief		设置Processing unit control
*	@param		uDeviceID					[IN] 				设备索引
*	@param		VideoProcAmp				[IN] 				Processing unit 属性,参数定义参见strmif.h定义
*	@param		val							[IN] 				当前值
*	@param		flags						[IN] 				自动/手动
*	@remarks	设置自动/手动之前，先获取设备PU属性支持的控制模式
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Processing unit control setting
*	@param		uDeviceID					[IN] 				Device index
*	@param		VideoProcAmp				[IN] 				Processing unit property For more details, refer to strmif.h.
*	@param		val							[IN] 				Current value
*	@param		flags						[IN] 				Automatic/manual
*	@remarks	Get the control modes of the device’s PU properties before setting auto/manual mode.
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_SetProcessingUnitControl(IN uint32_t uDeviceID, IN enum tagVideoProcAmpProperty VideoProcAmp, IN long val, IN long flags);

/********************************************************************//**
*	@ingroup UVC_PU
*	@~chinese
*	@brief		获取Camera Terminal Control
*	@param		uDeviceID					[IN] 				设备索引
*	@param		VideoProcAmp				[IN] 				Camera Terminal 属性,参数定义参见strmif.h定义
*	@param		val							[IN][OUT] 			当前值
*	@param		flags						[IN][OUT] 			自动/手动
*	@param		step						[IN][OUT] 			步长
*	@param		min							[IN][OUT] 			最小值
*	@param		max							[IN][OUT] 			最大值
*	@param		def							[IN][OUT] 			默认值
*	@param		pCapsFlags					[IN][OUT] 			获取当前设备Camera Terminal属性支持的控制模式,如:1，自动控制；2：手动控制；3：自动、手动控制
*	@remarks    使用低亮度补偿功能，输入VideoProcAmp = 19，赋值val来控制
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Camera Terminal Control retrieval
*	@param		uDeviceID					[IN] 				Device index
*	@param		VideoProcAmp				[IN] 				Camera Terminal property For more details, refer to strmif.h.
*	@param		val							[IN][OUT] 			Current value
*	@param		flags						[IN][OUT] 			Automatic/manual
*	@param		step						[IN][OUT] 			Step size
*	@param		min							[IN][OUT] 			Minimum value
*	@param		max							[IN][OUT] 			Maximum value
*	@param		def							[IN][OUT] 			Default value
*	@param		pCapsFlags					[IN][OUT] 			Get the control mode supported by the current device's Camera Terminal properties. For example: 1: Automatic control; 2: Manual control; 3: Both automatic and manual control
*	@remarks    To use the low-light compensation function, set VideoProcAmp = 19 and assign a value to val for control
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_GetCameraTerminalControl(IN uint32_t uDeviceID, IN enum tagCameraControlProperty VideoProcAmp, IN OUT long *val, IN OUT long *flags, IN OUT long *step, IN OUT long*min, IN OUT long* max, IN OUT long *def, IN OUT long *pCapsFlags);

/********************************************************************//**
*	@ingroup UVC_PU
*	@~chinese
*	@brief		设置Camera Terminal Control
*	@param		uDeviceID					[IN] 				设备索引
*	@param		VideoProcAmp				[IN] 				Camera Terminal 属性,参数定义参见strmif.h定义
*	@param		val							[IN] 				当前值
*	@param		flags						[IN] 				自动/手动
*	@remarks	设置自动/手动之前，先获取设备PU属性支持的控制模式
*	@remarks    使用低亮度补偿功能，输入VideoProcAmp = 19
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Camera Terminal Control setting
*	@param		uDeviceID					[IN] 				Device index
*	@param		VideoProcAmp				[IN] 				Camera Terminal property For more details, refer to strmif.h.
*	@param		val							[IN] 				Current value
*	@param		flags						[IN] 				Automatic/manual
*	@remarks	Get the control modes of the device’s PU properties before setting auto/manual mode.
*	@remarks    To use the low-light compensation function, set VideoProcAmp = 19
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_SetCameraTerminalControl(IN uint32_t uDeviceID, IN enum tagCameraControlProperty VideoProcAmp, IN long val, IN long flags);


/** @} endgroup UVC_PU */


/************************** ISP / Image Parameter Control **************************/

/**
 * @defgroup ISP_Control ISP_Control
 * @ingroup Device
 * @brief
 * @~chinese ISP 图像参数控制与功能
 * @~chinese - 视频类型
 * @~chinese - 多路视频图像位置互换
 * @~chinese - 镜头矫正功能
 * @~chinese - 单次自动白平衡
 * @~chinese - 单次自动聚焦
 * @~chinese - 单次自动曝光
 * @~chinese - 图像偏移
 * @~chinese - 白平衡增益
 * @~english ISP image parameter control and features
 * @~english - Video type
 * @~english - Multi channel video location exchange
 * @~english - Lens correction function
 * @~english - Single Automatic White Balance
 * @~english - Single autofocus
 * @~english - Single automatic exposure
 * @~english - Image offset
 * @~english - White Balance Gain
 * @{
 */

 /********************************************************************//**
 *	@ingroup ISP_Control
 *	@~chinese
 *	@brief		获取视频类型（RGB/MONO/RAW）
 *	@param		uDeviceID					[IN] 				设备索引
 *	@param		pType						[IN][OUT] 			返回视频类型（见 E_VIDEO_TYPE）
 *	@remarks	视频类型详细在E_VIDEO_TYPE中有说明(暂时仅支持Gen060)
 *	@return		成功，返回NORI_OK；错误，返回错误码

 *	@~english
 *	@brief		Get Video Type
 *	@param		uDeviceID					[IN] 				Device index
 *	@param		pType						[IN][OUT] 			Returns video type (see E_VIDEO_TYPE)
 *	@remarks	For details, please refer to E_VIDEO_TYPE(currently only Gen060 is supported)
 *	@return		Success returns NORI_OK; Error returns an error code
  ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_GetVideoType(IN uint32_t uDeviceID, IN OUT E_VIDEO_TYPE *pType);

/********************************************************************//**
*	@ingroup ISP_Control
*	@~chinese
*	@brief		设置视频类型（RGB/MONO/RAW）
*	@param		uDeviceID					[IN] 				设备索引
*	@param		Type						[IN]				要设置的视频类型（见 E_VIDEO_TYPE）
*	@remarks	视频类型详细在E_VIDEO_TYPE中有说明
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Set Video Type
*	@param		uDeviceID					[IN] 				Device index
*	@param		Type						[IN] 				Video type to set (see E_VIDEO_TYPE)
*	@remarks	For details, please refer to E_VIDEO_TYPE
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_SetVideoType(IN uint32_t uDeviceID, IN E_VIDEO_TYPE Type);


/********************************************************************//**
*	@ingroup ISP_Control
*	@~chinese
*	@brief		获取多路视频图像位置互换状态
*	@param		uDeviceID					[IN] 				设备索引
*	@param		pValue						[IN][OUT] 			0:正常模式 1：左右互换模式
*	@remarks	仅支持双Sensor方案
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Get the status after Multiple Video Swap
*	@param		uDeviceID					[IN] 				Device index
*	@param		pValue						[IN][OUT] 			Returns 0 (normal) or 1 (swapped)
*	@remarks	Only supports dual-sensor solution
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_GetMultipleVideoSwap(IN uint32_t uDeviceID, IN OUT uint32_t *pValue);

/********************************************************************//**
*	@ingroup ISP_Control
*	@~chinese
*	@brief		设置多路视频图像位置互换状态
*	@param		uDeviceID					[IN] 				设备索引
*	@param		pValue						[IN] 				0:正常模式 1：左右互换模式
*	@remarks	仅支持双Sensor方案
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Set Multiple Video Swap
*	@param		uDeviceID					[IN] 				Device index
*	@param		pValue						[IN] 				0=normal, 1=swapped
*	@remarks	Only supports dual-sensor solution
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_SetMultipleVideoSwap(IN uint32_t uDeviceID, IN uint32_t uValue);

/********************************************************************//**
*	@ingroup ISP_Control
*	@~chinese
*	@brief		获取镜头矫正功能开启/关闭
*	@param		uDeviceID					[IN] 				设备索引
*	@param		pValue						[IN][OUT] 			镜头矫正功能状态；1：开启，0：关闭
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Get the status of Lens Correction
*	@param		uDeviceID					[IN] 				Device index
*	@param		pValue						[IN][OUT] 			The status of Lens Correction
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_GetLensCorrectionEnable(IN uint32_t uDeviceID, IN OUT uint32_t *pValue);

/********************************************************************//**
*	@ingroup ISP_Control
*	@~chinese
*	@brief		设置镜头矫正功能开启/关闭
*	@param		uDeviceID					[IN] 				设备索引
*	@param		pValue						[IN] 				镜头矫正功能状态；1：开启，0：关闭
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Set the status of Lens Correction
*	@param		uDeviceID					[IN] 				Device index
*	@param		pValue						[IN]				The status of Lens Correction
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_SetLensCorrectionEnable(IN uint32_t uDeviceID, IN uint32_t uValue);

/********************************************************************//**
*	@ingroup ISP_Control
*	@~chinese
*	@brief		设置一次自动白平衡（一次性）
*	@param		uDeviceID					[IN] 				设备索引
*	@remarks	用户调用一次此函数，设备做一次自动白平衡后进入稳定模式，不再随外部环境改变而调整白平衡
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Set one-time auto White Balance
*	@param		uDeviceID					[IN] 				Device index
*	@remarks	Performs one-time auto white balance and then locks it
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_SetSingleAutoWhiteBalance(IN uint32_t uDeviceID);

/********************************************************************//**
*	@ingroup ISP_Control
*	@~chinese
*	@brief		获取一次性自动白平衡状态（0: 完成, 1: 设置中）
*	@param		uDeviceID					[IN] 				设备索引
*	@param		pValue						[IN][OUT] 			白平衡状态，如：0:设置完成 1：设置中
*	@remarks	用户调用一次此函数，设备做一次自动白平衡后进入稳定模式，不再随外部环境改变而调整白平衡
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Get the status of auto White Balance
*	@param		uDeviceID					[IN] 				Device index
*	@param		pValue						[IN][OUT] 			The status of auto White Balance. For example,0:Setting completed, 1: Setting in progress
*	@remarks	Performs one-time auto white balance and then locks it
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_GetSingleAutoWhiteBalance(IN uint32_t uDeviceID, IN OUT uint32_t *pValue);

/********************************************************************//**
*	@ingroup ISP_Control
*	@~chinese
*	@brief		触发一次自动聚焦（一次性）
*	@param		uDeviceID					[IN] 				设备索引
*	@remarks	用户调用一次此函数，设备做一次自动聚焦后进入稳定模式，不再随外部环境改变而调整聚焦
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Set one-time auto Focus
*	@param		uDeviceID					[IN] 				Device index
*	@remarks	Performs one-time auto Focus and then locks it
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_SetSingleAutoFocus(IN uint32_t uDeviceID);

/********************************************************************//**
*	@ingroup ISP_Control
*	@~chinese
*	@brief		获取一次性自动聚焦状态（0: 完成, 1: 设置中）
*	@param		uDeviceID					[IN] 				设备索引
*	@param		pValue						[IN][OUT] 			聚焦状态，如：0:设置完成 1：设置中
*	@remarks	用户调用一次此函数，设备做一次自动聚焦后进入稳定模式，不再随外部环境改变而调整聚焦
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Get the status of auto Focus
*	@param		uDeviceID					[IN] 				Device index
*	@param		pValue						[IN][OUT] 			The status of auto Focus. For example,0: Setting completed, 1: Setting in progress
*	@remarks	Performs one-time auto Focus and then locks it
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_GetSingleAutoFocus(IN uint32_t uDeviceID, IN OUT uint32_t *pValue);

/********************************************************************//**
*	@ingroup ISP_Control
*	@~chinese
*	@brief		触发一次自动曝光（一次性）
*	@param		uDeviceID					[IN] 				设备索引
*	@remarks	用户调用一次此函数，设备做一次自动曝光后进入稳定模式，不再随外部环境改变而调整曝光
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Set one-time auto Exposure
*	@param		uDeviceID					[IN] 				Device index
*	@remarks	Performs one-time auto Exposure and then locks it
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_SetSingleAutoExposure(IN uint32_t uDeviceID);

/********************************************************************//**
*	@ingroup ISP_Control
*	@~chinese
*	@brief		获取一次性自动曝光状态（0: 完成, 1: 设置中）
*	@param		uDeviceID					[IN] 				设备索引
*	@param		pValue						[IN][OUT] 			曝光状态，如：0:设置完成 1：设置中
*	@remarks	用户调用一次此函数，设备做一次自动曝光后进入稳定模式，不再随外部环境改变而调整曝光
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Get the status of auto Exposure
*	@param		uDeviceID					[IN] 				Device index
*	@param		pValue						[IN][OUT] 			The status of auto Exposure. For example,0: Setting completed, 1: Setting in progress
*	@remarks	Performs one-time auto Exposure and then locks it
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_GetSingleAutoExposure(IN uint32_t uDeviceID, IN OUT uint32_t *pValue);


/********************************************************************//**
*	@ingroup ISP_Control
*	@~chinese
*	@brief		获取图像偏移（ROI 偏移）
*	@param		uDeviceID					[IN] 				设备索引
*	@param		pValue						[IN][OUT] 			返回偏移信息（见 XY_OFFSET）
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Get Image offset
*	@param		uDeviceID					[IN] 				Device index
*	@param		pValue						[IN][OUT] 			Image offset value
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_GetImageOffset(IN uint32_t uDeviceID, IN OUT XY_OFFSET *pOffset);

/********************************************************************//**
*	@ingroup ISP_Control
*	@~chinese
*	@brief		设置图像偏移（ROI）
*	@param		uDeviceID					[IN] 				设备索引
*	@param		pValue						[IN] 				偏移值（见 XY_OFFSET）
*	@return		成功，返回NORI_OK；错误，返回错误码
* 	@remarks 	偏移值需为2的倍数
*	@~english
*	@brief		Set Image offset
*	@param		uDeviceID					[IN] 				Device index
*	@param		pValue						[IN]				Image offset value
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_SetImageOffset(IN uint32_t uDeviceID, IN XY_OFFSET Offset);

/********************************************************************//**
*	@ingroup ISP_Control
*	@~chinese
*	@brief		获取白平衡增益
*	@param		uDeviceID					[IN] 				设备索引
*	@param		pValue						[IN][OUT] 			返回白平衡增益（见 WB_RGB_GAIN）
*	@remarks	(暂时仅支持Gen060)
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Get White Balance Gain
*	@param		uDeviceID					[IN] 				Device index
*	@param		pValue						[IN][OUT] 			Returns white balance gain (see WB_RGB_GAIN)
*	@remarks	(currently only Gen060 is supported)
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_GetWhiteBalanceGain(IN uint32_t uDeviceID, IN OUT WB_RGB_GAIN* pGain);

/********************************************************************//**
*	@ingroup ISP_Control
*	@~chinese
*	@brief		设置白平衡增益（手动）
*	@param		uDeviceID					[IN] 				设备索引
*	@param		Gain						[IN]				增益值（见 WB_RGB_GAIN）
*	@remarks	进行白平衡增益设置前，需先将 白平衡 设置为手动设置，可通过 Nori_Xvision_SetCameraTerminalControl 接口进行设置(暂时仅支持Gen060)
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Set White Balance Gain
*	@param		uDeviceID					[IN] 				Device index
*	@param		Gain						[IN]				White balance gain (see WB_RGB_GAIN)
*	@remarks	Before setting the White Balance Gain, make sure to set the White Balance to manual mode using the Nori_Xvision_SetCameraTerminalControl(currently only Gen060 is supported)
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_SetWhiteBalanceGain(IN uint32_t uDeviceID, IN WB_RGB_GAIN Gain);

 /** @} endgroup ISP_Control */


/************************** Sensor Control **************************/

/**
 * @defgroup Sensor_Control Sensor_Control
 * @ingroup Device
 * @brief
 * @~chinese Sensor 级别控制
 * @~chinese - raw 属性
 * @~chinese - 黑电平
 * @~chinese - 快门时间
 * @~chinese - 增益倍数
 * @~chinese - 镜像/翻转
 * @~english Sensor-level control
 * @~english - Raw attribute
 * @~english - Black level
 * @~english - Shutter Time
 * @~english - Gain multiplier
 * @~english - Mirror/Flip
 * @{
 */
/********************************************************************//**
*	@ingroup Sensor_Control
*	@~chinese
*	@brief		获取RAW格式属性
*	@param		uDeviceID					[IN] 				设备索引
*	@param		pRawInfo					[IN][OUT]			RAW格式属性,如：原始深度、颜色编码
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Get exposure time
*	@param		uDeviceID					[IN] 				Device index
*	@param		pRawInfo					[IN][OUT]			Arrangement format，For example,Raw depth 、color coding.
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_GetSensorRawInfo(IN uint32_t uDeviceID, IN OUT SENSOR_RAW_INFO *pRawInfo);


/********************************************************************//**
*	@ingroup Sensor_Control
*	@~chinese
*	@brief		获取BlackLevel
*	@param		uDeviceID					[IN] 				设备索引
*	@param		pValue						[IN][OUT]			返回黑电平值
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Get BlackLevel
*	@param		uDeviceID					[IN] 				Device index
*	@param		pValue						[IN][OUT]			Returns black level value
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_GetSensorBlackLevel(IN uint32_t uDeviceID, IN OUT uint32_t *pValue);


/********************************************************************//**
@ingroup Sensor_Control
*	@~chinese
*	@brief		设置BlackLevel
*	@param		uDeviceID					[IN] 				设备索引
*	@param		pValue						[IN][OUT]			黑电平值
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Set BlackLevel
*	@param		uDeviceID					[IN] 				Device index
*	@param		pValue						[IN][OUT]			Black level value
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_SetSensorBlackLevel(IN uint32_t uDeviceID, IN uint32_t uValue);

/********************************************************************//**
*	@ingroup Sensor_Control
*	@~chinese
*	@brief		获取增益（单位：倍数）
*	@param		uDeviceID					[IN] 				设备索引
*	@param		pCur						[IN][OUT]			增益倍数
*	@param		pMin						[IN][OUT]			增益最小值
*	@param		pMax						[IN][OUT]			增益最大值
*	@param		pStep						[IN][OUT]			增益步进值
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Get gain(unit:multiple)
*	@param		uDeviceID					[IN] 				Device index
*	@param		pCur						[IN][OUT]			Gain Value
*	@param		pMin						[IN][OUT]			Gain Min Value
*	@param		pMax						[IN][OUT]			Gain Max Value
*	@param		pStep						[IN][OUT]			Gain Step Value
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_GetSensorGain(IN uint32_t uDeviceID, IN OUT uint32_t *pCur, IN OUT uint32_t *pMin, IN OUT uint32_t *pMax, IN OUT uint32_t *pStep);

/********************************************************************//**
*	@ingroup Sensor_Control
*	@~chinese
*	@brief		设置增益
*	@param		uDeviceID					[IN] 				设备索引
*	@param		uValue						[IN]				增益倍数
*	@remarks	进行增益设置前，需先将增益设置为手动，可通过 Nori_Xvision_SetProcessingUnitControl 接口进行设置
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Set gain
*	@param		uDeviceID					[IN] 				Device index
*	@param		uValue						[IN]				Gain value
*	@remarks	Before setting the Gain, make sure to set the Gain to manual mode using the Nori_Xvision_SetProcessingUnitControl
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_SetSensorGain(IN uint32_t uDeviceID, IN uint32_t uValue);


/********************************************************************//**
*	@ingroup Sensor_Control
*	@~chinese
*	@brief		获取快门/曝光时间（单位：微秒）
*	@param		uDeviceID					[IN] 				设备索引
*	@param		pValue						[IN][OUT]			曝光时间值()
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Get exposure time
*	@param		uDeviceID					[IN] 				Device index
*	@param		pValue						[IN][OUT]			Exposure time value
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_GetSensorShutter(IN uint32_t uDeviceID, IN OUT uint32_t *pValue);

/********************************************************************//**
*	@ingroup Sensor_Control
*	@~chinese
*	@brief		设置快门/曝光时间（单位：微秒）
*	@param		uDeviceID					[IN] 				设备索引
*	@param		uValue						[IN]				曝光时间值
*	@remarks	进行曝光时间设置前，需先将 曝光 设置为手动曝光，可通过 Nori_Xvision_SetCameraTerminalControl 接口进行设置
				具体请看Nori_Xvision_SetCameraTerminalControl
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Set exposure time
*	@param		uDeviceID					[IN] 				Device index
*	@param		uValue						[IN]				Exposure time value
*	@remarks	Before setting the exposure time, make sure to set the exposure to manual mode using the Nori_Xvision_SetCameraTerminalControl
				For details, please refer to Nori_Xvision_SetCameraTerminalControl
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_SetSensorShutter(IN uint32_t uDeviceID, IN uint32_t uValue);


/********************************************************************//**
*	@ingroup Sensor_Control
*	@~chinese
*	@brief		获取设备镜像&翻转状态
*	@param		uDeviceID					[IN] 				设备索引
*	@param		pMirrorFlip					[IN][OUT]			要设置的镜像/翻转状态（见 E_SENSOR_MIRROR_FLIP）
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Get the status of Sensor Mirror & Flip
*	@param		uDeviceID					[IN] 				Device index
*	@param		pMirrorFlip					[IN][OUT]			Returns mirror/flip state (see E_SENSOR_MIRROR_FLIP)
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_GetSensorMirrorFlip(IN uint32_t uDeviceID, IN OUT E_SENSOR_MIRROR_FLIP* pMirrorFlip);

/********************************************************************//**
*	@ingroup Sensor_Control
*	@~chinese
*	@brief		设置设备镜像&翻转状态
*	@param		uDeviceID					[IN] 				设备索引
*	@param		MirrorFlip					[IN]				要设置的镜像/翻转状态（见 E_SENSOR_MIRROR_FLIP）
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Set the status of Sensor Mirror & Flip
*	@param		uDeviceID					[IN] 				Device index
*	@param		MirrorFlip					[IN]				Returns mirror/flip state (see E_SENSOR_MIRROR_FLIP)
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_SetSensorMirrorFlip(IN uint32_t uDeviceID, IN E_SENSOR_MIRROR_FLIP MirrorFlip);

/** @} endgroup Sensor_Control */



/************************** User Data / ESN **************************/

/**
 * @defgroup User_Data_Control User_Data_Control
 * @ingroup Device
 * @brief
 * @~chinese 用户自定义数据读写与ESN
 * @~chinese - 用户自定义数据
 * @~chinese  - 数据只能通过接口函数读写
 * @~chinese  - Gen60数据分256个区域，每个区域可存储4096个字节，共计1MB，数据存储在非易失性存储区域
 * @~chinese  - Gen56数据分64个区域，每个区域可存储4096个字节，共计256KB，数据存储在非易失性存储区域
 * @~chinese  - 设备重新上电/设备固件更新不影响用户自定义写入的数据
 * @~chinese - ESN
 * @~chinese  - 只能通过固件更新的方式写入设备
 * @~chinese  - 设备固件更新,原有设备里面的ESN数据会丢失，新的ESN数据为固件里的ESN数据
 * @~chinese - 建议用户将数据保存在自定义数据区
 * @~english User data read/write and ESN
 * @~english - User defined data
 * @~english  - Data can only be read and written through interface functions
 * @~english  - Gen60 The data is divided into 256 regions, each of which can store 4096 bytes, totaling 1MB. The data is stored in non-volatile storage areas
 * @~english  - Gen56 The data is divided into 64 regions, each of which can store 4096 bytes, totaling 256KB. The data is stored in non-volatile storage areas
 * @~english  - Device re powering on/Device firmware update does not affect user-defined data writing
 * @~english - ESN
 * @~english  - can only be written to the device through firmware updates
 * @~english  - Device firmware update, the ESN data in the original device will be lost, and the new ESN data will be the ESN data in the firmware
 * @~english - It is recommended that users save their data in a custom data area
 * @{
 */

/********************************************************************//**
*	@ingroup User_Data_Control
*	@~chinese
*	@brief		获取用户自定义数据
*	@param		uDeviceID					[IN] 			设备索引
*	@param		iPieceIndex					[IN] 			数据分区索引（Gen60支持0~255;Gen56支持0~63）
*	@param		pbuff						[IN][OUT] 		用户数据（buf位数只能为0x1000）
*	@remarks	
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Get User Data
*	@param		uDeviceID					[IN]			Device index
*	@param		iPieceIndex					[IN] 			Memory block index（Gen60 support 0~255;Gen56 support 0~63）
*	@param		pbuff						[IN][OUT] 		User Data(Data size must be 0x1000)
*	@return		Success, return NORI_OK; Error, return error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_GetUserData(IN uint32_t uDeviceID, IN uint32_t iPieceIndex, IN OUT BYTE* pbuff);

/********************************************************************//**
*	@ingroup User_Data_Control
*	@~chinese
*	@brief		设置用户自定义数据
*	@param		uDeviceID					[IN] 			设备索引
*	@param		iPieceIndex					[IN] 			数据分区索引（Gen60支持0~255;Gen56支持0~63）
*	@param		pbuff						[IN][OUT] 		用户数据（buf位数只能为0x1000）
*	@remarks	
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Set User Data
*	@param		uDeviceID					[IN]			Device index
*	@param		iPieceIndex					[IN] 			Memory block index（Gen60 support 0~255;Gen56 support 0~63）
*	@param		pbuff						[IN][OUT] 		User Data(Data size must be 0x1000)
*	@return		Success, return NORI_OK; Error, return error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_SetUserData(IN uint32_t uDeviceID, IN uint32_t iPieceIndex, IN BYTE* pbuff);

/********************************************************************//**
*	@ingroup User_Data_Control
*	@~chinese
*	@brief		获取用户自定义序列号
*	@param		uDeviceID					[IN] 			设备索引
*	@param		pbuff						[IN][OUT] 		用户设备序列号（buf位数只能为0x40）
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Get User ESN
*	@param		uDeviceID					[IN]			Device index
*	@param		pbuff						[IN][OUT] 		User ESN Data(Data size must be 0x40)
*	@return		Success, return NORI_OK; Error, return error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_GetUserESN(IN uint32_t uDeviceID, IN OUT BYTE* pbuff);

/********************************************************************//**
*	@ingroup User_Data_Control
*	@~chinese
*	@brief		设置用户自定义序列号	(Gen060不支持)
*	@param		uDeviceID					[IN] 			设备索引
*	@param		pbuff						[IN] 			用户设备序列号
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Set User ESN(Not supported on Gen060 now)
*	@param		uDeviceID					[IN]			Device index
*	@param		pbuff						[IN] 			User ESN Data
*	@return		Success, return NORI_OK; Error, return error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_SetUserESN(IN uint32_t uDeviceID, IN BYTE* pbuff);

/********************************************************************//**
*	@ingroup User_Data_Control
*	@~chinese
*	@brief		用户自定义握手交互	
*	@param		uDeviceID					[IN] 			设备索引
*	@param		pData						[IN] 			用户自定义数据（buf位数只能为0x08）
*	@param		len							[IN] 			用户自定义数据长度（buf位数只能为0x08）
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		User APP Check Data
*	@param		uDeviceID					[IN]			Device index
*	@param		pData						[IN] 			User  Data（Data size must be 0x08）
*	@param		len							[IN] 			User  Data Len（Data size must be 0x08）
*	@return		Success, return NORI_OK; Error, return error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_DeviceCheck(IN uint32_t uDeviceID, IN uint8_t *pData, IN uint32_t len);
/** @} endgroup User_Data_Control */



/************************** Firmware Update **************************/

/**
 * @defgroup Firmware_Update Firmware_Update
 * @ingroup Device
 * @brief
 * @~chinese 设备固件更新
 * @~english Device firmware update
 * @{
 */

 /********************************************************************//**
 *	@ingroup Firmware_Update
 *	@~chinese
 *	@brief		固件更新
 *	@param		uDeviceID					[IN] 			设备索引
 *	@param		pbyFW						[IN] 			固件数据地址
 *	@param		uSize						[IN] 			固件数据长度
 *	@param		pf_Schedule					[IN][OUT] 		固件更新进度
 *	@return		成功，返回NORI_OK；错误，返回错误码

 *	@~english
 *	@brief		FirmWare Update
 *	@param		uDeviceID					[IN]			Device index
 *	@param		pbyFW						[IN] 			FirmWare Address
 *	@param		uSize						[IN] 			FirmWare Size
 *	@param		pf_Schedule					[IN][OUT] 		The progress of the FirmWare Update
 *	@return		Success, return NORI_OK; Error, return error code
  ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_FirmWareUpdate(IN uint32_t uDeviceID, IN BYTE *pbyFW, IN uint32_t uSize, IN OUT float *pf_Schedule);

/** @} endgroup Firmware_Update */




/************************** GPIO / IO Control **************************/

/**
 * @defgroup GPIO_Control GPIO_Control
 * @ingroup Device
 * @brief
 * @~chinese GPIO 控制
 * @~chinese - GPIO口普通控制
 * @~chinese - GPIO口PWM控制
 * @~english GPIO control
 * @~english - GPIO port ordinary control
 * @~english - GPIO Port PWM Control
 * @{
 */

 /********************************************************************//**
 *	@ingroup GPIO_Control
 *	@~chinese
 *	@brief		获取IO引脚模式&电平
 *	@param		uDeviceID					[IN] 				设备索引
 *	@param		IO_ID						[IN] 				引脚 ID（参见 E_GPIO_ID）
 *	@param		IoControl					[IN] 				IO 配置（见 IO_CONTORL）
 *	@return		成功，返回NORI_OK；错误，返回错误码

 *	@~english
 *	@brief		Get IO pin mode and level
 *	@param		uDeviceID					[IN] 				Device index
 *	@param		IO_ID						[IN] 				Pin ID (see E_GPIO_ID)
 *	@param		IoControl					[IN] 				IO control values (see IO_CONTORL)
 *	@return		Success returns NORI_OK; Error returns an error code
  ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_SetIO(IN uint32_t uDeviceID, IN E_GPIO_ID IO_ID, IN IO_CONTORL IoControl);

/********************************************************************//**
*	@ingroup GPIO_Control
*	@~chinese
*	@brief		设置IO引脚模式&电平
*	@param		uDeviceID					[IN] 				设备索引
*	@param		IO_ID						[IN] 				引脚 ID（参见 E_GPIO_ID）
*	@param		pIoControl					[IN][OUT] 			返回 IO 配置
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Get IO pin mode and level
*	@param		uDeviceID					[IN] 				Device index
*	@param		IO_ID						[IN] 				Pin ID (see E_GPIO_ID)
*	@param		pIoControl					[IN][OUT] 			Returns IO control values
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_GetIO(IN uint32_t uDeviceID, IN E_GPIO_ID IO_ID, IN OUT IO_CONTORL *pIoControl);

/********************************************************************//**
*	@ingroup GPIO_Control
*	@~chinese
*	@brief		获取PWM频率和占空比
*	@param		uDeviceID					[IN] 				设备索引
*	@param		pValue						[IN][OUT] 			返回 PWM 频率与占空比（见 FREQUENCY_RATIO）
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Get PWM frequency and duty cycle
*	@param		uDeviceID					[IN] 				Device index
*	@param		pValue						[IN][OUT] 			Returns PWM frequency and duty cycle (see FREQUENCY_RATIO)
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_GetPWMFrequencyRatio(IN uint32_t uDeviceID, IN OUT FREQUENCY_RATIO *pValue);

/********************************************************************//**
*	@ingroup GPIO_Control
*	@~chinese
*	@brief		设置PWM频率和占空比
*	@param		uDeviceID					[IN] 				设备索引
*	@param		pValue						[IN] 				要设置的频率/占空比（见 FREQUENCY_RATIO）
*	@return		成功，返回NORI_OK；错误，返回错误码

*	@~english
*	@brief		Set PWM frequency and duty cycle
*	@param		uDeviceID					[IN] 				Device index
*	@param		pValue						[IN] 				Frequency and duty cycle to set (see FREQUENCY_RATIO)
*	@return		Success returns NORI_OK; Error returns an error code
 ************************************************************************/
NORI_CAMCTRL_API uint32_t Nori_Xvision_SetPWMFrequencyRatio(IN uint32_t uDeviceID, IN FREQUENCY_RATIO uValue);

/** @} endgroup GPIO_Control */

/** @}*/

/**
 * @defgroup Image Image
 * @brief
 * @~chinese 图像解码
 * @~english Image decoding
 *@{
 */

 /**
 * @ingroup Image
 * @~chinese
 * @brief   raw10解码成BGR24数据
 * @param   raw             [IN]        raw数据
 * @param   width           [IN]        图像宽度
 * @param   height          [IN]        图像高度
 * @param   out_bgr         [IN][OUT]   BGR24数据缓冲（调用方分配）
 * @param   pattern         [IN]        颜色排列方式
 * @param   black_level     [IN]        黑电平
 * @note	   BGR24数据按从上到下排列（第一行是图像顶部)
 * @return  无

 * @~english
 * @brief   decoded raw10 to BGR24 data
 * @param   raw             [IN]        raw data
 * @param   width           [IN]        image width
 * @param   height          [IN]        image height
 * @param   out_bgr         [IN][OUT]   BGR24 buff（caller allocated）
 * @param   pattern         [IN]        Color arrangement
 * @note	   Data is arranged from top to bottom (the first row is at the top of the image)
 * @param   black_level     [IN]        black level
 * @return  无
 */
NORI_IMAGECTRL_API void Nori_Xvision_Raw10ToBGR24(IN const uint16_t* raw, IN uint32_t width, IN uint32_t height, IN OUT uint8_t* out_bgr, IN E_SENSOR_COLOR_CODING pattern, IN uint32_t black_level);

/**
* @ingroup Image
* @~chinese
* @brief   YUYV解码成BGR24数据
* @param   raw             [IN]        yuyv数据
* @param   out_bgr         [IN][OUT]   BGR24数据缓冲（调用方分配）
* @param   width           [IN]        图像宽度
* @param   height          [IN]        图像高度
* @note	   BGR24数据按从上到下排列（第一行是图像顶部)
* @return  无

* @~english
* @brief   decoded raw10 to BGR24 data
* @param   raw             [IN]        raw data
* @param   out_bgr         [IN][OUT]   BGR24 buff（caller allocated）
* @param   width           [IN]        image width
* @param   height          [IN]        image height
* @note	   Data is arranged from top to bottom (the first row is at the top of the image)
* @return  无
*/
NORI_IMAGECTRL_API void Nori_Xvision_YuyvToBGR24(IN uint8_t* yuyv, IN OUT uint8_t* out_bgr, IN int width, IN int height);

/**
* @ingroup Image
* @~chinese
* @brief   保存BRG24到本地
* @param   filename        [IN]        文件名
* @param   bgr24           [IN]        BGR24数据
* @param   width           [IN]        图像宽度
* @param   height          [IN]        图像高度
* @param  topDown   [IN]   指示传入的 BGR24 像素数据的行序是否为自上而下（top-down）存储。
*- true  : 数据按从上到下排列（第一行是图像顶部）
*- false : 数据按从下到上排列（第一行是图像底部）
* @return  false:文件打开失败；true：成功

* @~english
* @brief   save BGR24 to local
* @param   filename        [IN]        file name
* @param   bgr24           [IN]        BGR24 data
* @param   width           [IN]        image width
* @param   height          [IN]        image height
* @param   topDown		   [IN]		   indicates whether the row order of the incoming BGR24 pixel data is stored in a top-down manner.
*- true: Data is arranged from top to bottom (the first row is at the top of the image)
*- false: The data is arranged from bottom to top (the first row is at the bottom of the image)
* @return  false:open file false; true: success
*/
NORI_IMAGECTRL_API bool Nori_Xvision_SaveBGR24ToBMP(IN const char* filename, IN const uint8_t* bgr24, IN uint32_t width, IN uint32_t height, IN bool topDown);
/** @}*/


#ifdef __cplusplus
}
#endif 
